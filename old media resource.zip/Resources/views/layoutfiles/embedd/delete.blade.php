<div id="delete-confirm-modal" data-uid="" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h2 class="modal-title">Are you sure?</h2>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-12">
                        <button data-dismiss="modal" id="no-delete" type="button" class="btn ink-reaction btn-primary pull-right">No</button>

                        <button id="yes-delete" type="button" class="btn ink-reaction btn-danger pull-right">Yes</button>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>